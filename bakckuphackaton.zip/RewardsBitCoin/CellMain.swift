//
//  CellMain.swift
//  RewardsBitCoin
//
//  Created by Eduardo Paganini on 12/2/17.
//  Copyright © 2017 Eduardo Paganini. All rights reserved.
//

import Foundation
import UIKit

class CellMain :UICollectionViewCell {
    @IBOutlet weak var outletImage: UIImageView!
    
}
