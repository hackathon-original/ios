//
//  ComprarViewController.swift
//  RewardsBitCoin
//
//  Created by Eduardo Paganini on 12/2/17.
//  Copyright © 2017 Eduardo Paganini. All rights reserved.
//

import Foundation
import UIKit

class ComprarViewController:UIViewController {
    
    override func viewDidLoad() {
        self.viewDidLoad()
     
    }
}
