//
//  SaberMaisViewController.swift
//  RewardsBitCoin
//
//  Created by Eduardo Paganini on 12/2/17.
//  Copyright © 2017 Eduardo Paganini. All rights reserved.
//

import Foundation
import UIKit

class SaberMaisViewController: UIViewController {
    
    @IBAction func touchDone(_ sender: Any) {
        
        self.dismiss(animated: true, completion: nil)
    }
    
    
}
